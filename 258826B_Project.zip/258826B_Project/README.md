
FINAL STABLE AML PROJECT

HOW TO RUN:
1. pip install catboost streamlit pandas scikit-learn plotly lime joblib
2. python src/train_model.py
3. python -m streamlit run streamlit_app/app.py
