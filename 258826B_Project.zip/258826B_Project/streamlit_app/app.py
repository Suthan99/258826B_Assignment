
import streamlit as st
import pandas as pd
import joblib
import plotly.express as px
from lime.lime_tabular import LimeTabularExplainer
from sklearn.preprocessing import LabelEncoder

st.set_page_config(page_title="Bank Deposit Prediction", layout="wide")

model = joblib.load("src/catboost_model.pkl")
df = pd.read_csv("data/bank_marketing.csv")

def clean_for_lime(df):
    df = df.copy()
    df = df.fillna(0)
    if "pdays" in df.columns:
        df["pdays"] = df["pdays"].apply(lambda x: 999 if x < 0 else x)
    return df

st.title("🏦 Bank Term Deposit Prediction")
st.write("Simple, explainable prediction system")

friendly_labels = {
    "age": "Customer Age",
    "job": "Occupation",
    "marital": "Marital Status",
    "education": "Education Level",
    "default": "Has Credit Default?",
    "balance": "Account Balance",
    "housing": "Has Housing Loan?",
    "loan": "Has Personal Loan?",
    "contact": "Contact Method",
    "day": "Last Contact Day",
    "month": "Last Contact Month",
    "duration": "Call Duration (seconds)",
    "campaign": "Contacts in This Campaign",
    "pdays": "Days Since Last Contact",
    "previous": "Previous Contacts Count",
    "poutcome": "Previous Campaign Outcome"
}

user_input = {}
for col in df.drop("y", axis=1).columns:
    if df[col].dtype == "object":
        user_input[col] = st.selectbox(friendly_labels[col], df[col].unique())
    else:
        user_input[col] = st.number_input(friendly_labels[col],
                                          float(df[col].min()),
                                          float(df[col].max()),
                                          float(df[col].median()))

input_df = pd.DataFrame([user_input])

pred = model.predict(input_df)[0]
prob = model.predict_proba(input_df)[0][1]

st.subheader("Prediction Result")
st.write("Likely to Subscribe" if pred == 1 else "Unlikely to Subscribe")
st.write("Probability:", round(prob, 2))

# Feature importance
importances = model.get_feature_importance()
features = [friendly_labels[f] for f in df.drop("y", axis=1).columns]
fig_imp = px.bar(x=features, y=importances, title="Key Influencing Factors")
fig_imp.update_layout(xaxis_tickangle=45)
st.plotly_chart(fig_imp, use_container_width=True)

# LIME
st.header("Why This Prediction Was Made")

X_lime = clean_for_lime(df.drop("y", axis=1))
encoders = {}
for col in X_lime.columns:
    if X_lime[col].dtype == "object":
        le = LabelEncoder()
        X_lime[col] = le.fit_transform(X_lime[col])
        encoders[col] = le

lime_input = clean_for_lime(input_df)
for col, le in encoders.items():
    lime_input[col] = le.transform(lime_input[col])

def predict_for_lime(encoded):
    temp = pd.DataFrame(encoded, columns=X_lime.columns)
    for col, le in encoders.items():
        temp[col] = le.inverse_transform(temp[col].astype(int))
    return model.predict_proba(temp)

explainer = LimeTabularExplainer(
    training_data=X_lime.values,
    feature_names=[friendly_labels[f] for f in X_lime.columns],
    class_names=["Not Subscribed", "Subscribed"],
    mode="classification"
)

exp = explainer.explain_instance(lime_input.iloc[0].values,
                                 predict_for_lime, num_features=6)

lime_df = pd.DataFrame(exp.as_list(), columns=["Factor", "Impact"])
fig_lime = px.bar(lime_df, x="Impact", y="Factor",
                  orientation="h", title="Prediction Explanation")
st.plotly_chart(fig_lime, use_container_width=True)
