
import os
import pandas as pd
from catboost import CatBoostClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, confusion_matrix
import joblib
import plotly.express as px

os.makedirs("reports", exist_ok=True)

df = pd.read_csv("data/bank_marketing.csv")
X = df.drop("y", axis=1)
y = df["y"].map({"yes": 1, "no": 0})

cat_features = [i for i, col in enumerate(X.columns) if X[col].dtype == "object"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model = CatBoostClassifier(iterations=300, depth=6, learning_rate=0.1,
                           loss_function="Logloss", eval_metric="AUC", verbose=False)
model.fit(X_train, y_train, cat_features=cat_features)

preds = model.predict(X_test)
probs = model.predict_proba(X_test)[:, 1]

print("Accuracy:", accuracy_score(y_test, preds))
print("F1 Score:", f1_score(y_test, preds))
print("ROC-AUC:", roc_auc_score(y_test, probs))

joblib.dump(model, "src/catboost_model.pkl")

cm = confusion_matrix(y_test, preds)
cm_df = pd.DataFrame(cm, index=["Not Subscribed", "Subscribed"],
                     columns=["Predicted No", "Predicted Yes"])
fig = px.imshow(cm_df, text_auto=True, title="Confusion Matrix")
fig.write_html("reports/confusion_matrix.html")
